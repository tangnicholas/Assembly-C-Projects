#define SYSCLK    72000000L // SYSCLK frequency in Hz
#define BAUDRATE    115200L // Baud rate of UART in bps
#define SMB_FREQUENCY 100000L   // I2C SCL clock rate (10kHz to 100kHz)
#define TIMER_0_FREQ 1000L