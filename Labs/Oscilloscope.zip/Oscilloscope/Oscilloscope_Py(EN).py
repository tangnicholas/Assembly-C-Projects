import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import sys, time, math
import serial
import serial.tools.list_ports
import time
from gtts import gTTS
import os
import threading

tts = gTTS(text="Welcome to our oscilloscope.", lang='en')
tts.save("intro.mp3")
os.system("intro.mp3")

try:
    ser.close() # try to close the last opened port
except:
    print('')

portlist=list(serial.tools.list_ports.comports())
for item in portlist:
    print (item[0])

# configure the serial port
ser = serial.Serial(
    port=item[0],
    baudrate=115200,
    parity=serial.PARITY_NONE,
    stopbits=serial.STOPBITS_TWO,
    bytesize=serial.EIGHTBITS
)
ser.isOpen()
xsize = 100

def data_gen():
    t = data_gen.t
    while True:
        t+=1
        strin = ser.readline()
        val1=float(strin)
        strin = ser.readline()
        val2=float(strin)
        yield t, val1, val2

def run(data):
    # update the data
    t,y1,y2 = data
    if t>-1 or t:
        xdata.append(t)
        ydata1.append(y1)
        ydata2.append(y2)
        if t>xsize: # Scroll to the left.
            ax.set_xlim(abs(t-xsize), t)
        line1.set_data(xdata, ydata1)
        line2.set_data(xdata, ydata2)

    return line1, line2

def on_close_figure(event):
    sys.exit(0)


data_gen.t = -1
fig = plt.figure()
fig.canvas.mpl_connect('close_event', on_close_figure)
ax = fig.add_subplot(111)
line1, = ax.plot([], [], lw=2, label='Reference Wave')
line2, = ax.plot([], [], lw=2, label='Test Wave')
ax.set_ylim(-1, 4)
ax.set_xlim(0, 100)
ax.grid()
ax.legend()
xdata, ydata1, ydata2 = [], [], []

# Important: Although blit=True makes graphing faster, we need blit=False to prevent
# spurious lines to appear when resizing the stripchart.
ani = animation.FuncAnimation(fig, run, data_gen, blit=False, interval=50, 
repeat=False)
plt.show()

# Release everything if job is finished
cap.release()
out.release()
cv2.destroyAllWindows()
