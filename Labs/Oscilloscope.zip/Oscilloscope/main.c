#include <EFM8LB1.h>
#include <stdio.h>
#include "lcd.h"

int getsn (char * buff, int len)
{
	int j;
	char c;
	
	for(j=0; j<(len-1); j++)
	{
		c=getchar();
		if ( (c=='\n') || (c=='\r') )
		{
			buff[j]=0;
			return j;
		}
		else
		{
			buff[j]=c;
		}
	}
	buff[j]=0;
	return len;
}

void main (void)
{
	float Period_1 = 0;
	float Frequency_1 = 0;
	float time_diff;
	float overflow_count = 0;
	float sum = 0;
	float v[5];
	float ph;
	int i;
	int j = 0;
	int mode = 0;
	char line1[15];
	
	// Configure the LCD and Timer
	LCD_4BIT();
	TIMER0_Init();
	
	// Configure PuTTy
	waitms(500); // Give PuTTy a chance to start before sending
	printf("\x1b[2J"); // Clear screen using ANSI escape sequence.
	printf ("EFM8 Magnitude and Phase Measurer. Exciting!\n"
	        "File: %s\n"
	        "Compiled: %s, %s\n\n",
	        __FILE__, __DATE__, __TIME__);
	
	// Configure ADC
	InitPinADC(1, 5); // Configure P1.5 as analog input (Voltage TEST)
	InitPinADC(1, 7); // Configure P1.7 as analog input (Voltage REF)
    InitADC();
	
	 // Display something in the LCD
   	//        1234567890123456
	LCDprint(" Please choose  ", 1, 1);
	LCDprint("   a language   ", 2, 1);
	
	while (j==0){
		if(P0_6 == 0){
			while(P0_6 == 0);
			j = 1; 
		}
		if(P0_4 == 0){
			while(P0_4 == 0);
			j = 2; 
		}
		printf("%d\n", j);
		waitms(200);
	}	
	if(j==1){
		LCDprint(" Welcome to the ", 1, 1);
		LCDprint(" Oscilloscope!! ", 2, 1);
	}
	if(j==2){
		LCDprint(" Bienvenido al  ", 1, 1);
		LCDprint(" Osciloscopio.  ", 2, 1);
	}	
	waitms(1000);
	LCDprint("NO SIGNAL INPUT", 1, 1);
	LCDprint("               ", 2, 1);
	while(1){
	
		if(P0_6 == 0){
			while(P0_6 == 0);
			mode = !mode; 
		}
		
		if(mode == 0){
			P0_7=0;
			TR0=1;
			// Measure half period at pin P1.6 (SQ REF)
			while (P1_6==1); // Wait for the signal to be zero
			while (P1_6==0); // Wait for the signal to be one
			TH0=0; TL0=0; // Reset the timer
			TR0=1;
			while(P1_6!=0){ // Wait for the signal to be zero{
				if(TF0==1){ // Did the 16-bit timer overflow?
					TF0=0;
					overflow_count++;
				}
			}
			while(P1_6!=1){ // Wait for the signal to be one
				if(TF0==1){ // Did the 16-bit timer overflow?
					TF0=0;
					overflow_count++;
				}
			}
		 	Period_1=(overflow_count*65536.0+TH0*256.0+TL0)*(12.0/SYSCLK);
		 	Period_1=Period_1*83.5;
		 	TR0=0;
			// [TH0,TL0] is half the period in multiples of 12/CLK, so:
	
			//Measure Peak Voltage of REFERENCE (sq wave)
			while (P1_6==1); // Wait for the signal to be zero
			while (P1_6==0); // Wait for the signal to be one
			TH0=0; TL0=0; overflow_count=0;// Reset the timer
			TR0=1;
			while ((overflow_count*65536.0+TH0*256.0+TL0)*(12.0/SYSCLK)*83.5 < Period_1/4){
				if(TF0==1){ // Did the 16-bit timer overflow?
					TF0=0;
					overflow_count++;
					}
				}
			TR0=0;
			v[3] = Volts_at_Pin(QFP32_MUX_P1_7);
			
			//is it a square wave?
			while (P1_6==1); // Wait for the signal to be zero
			while (P1_6==0); // Wait for the signal to be one
			TH0=0; TL0=0; overflow_count=0;// Reset the timer
			TR0=1;
			while ((overflow_count*65536.0+TH0*256.0+TL0)*(12.0/SYSCLK)*83.5 < Period_1/8){
				if(TF0==1){ // Did the 16-bit timer overflow?
					TF0=0;
					overflow_count++;
					}
				}
			TR0=0;
			v[4] = Volts_at_Pin(QFP32_MUX_P1_7);
	
			overflow_count = 0;
			//Measure Peak Voltage of TEST (sq wave)
			while (P1_3==1); // Wait for the signal to be zero
			while (P1_3==0); // Wait for the signal to be one
			TH0=0; TL0=0; // Reset the timer
			TR0=1;
			while ((overflow_count*65536.0+TH0*256.0+TL0)*(12.0/SYSCLK)*83.5 < Period_1/4){
				if(TF0==1){ // Did the 16-bit timer overflow?
					TF0=0;
					overflow_count++;
					}
				}
			TR0=0;
			v[1] = Volts_at_Pin(QFP32_MUX_P1_5);
			waitms(50);

			while (P1_6==0); // Wait for the signal to be zero
			while (P1_6==1); // Wait for the signal to be one
			TH0=0; TL0=0; overflow_count=0; TF0=0;// Reset the timer
			TR0=1;
			if(P1_3!=0){
				while(P1_3!=0){ // Wait for the signal to be zero{
					if(TF0==1){ // Did the 16-bit timer overflow?
						TF0=0;
						overflow_count++;
					}
				}
			}
			else if(P1_3!=1){
				while(P1_3!=1){ // Wait for the signal to be zero{
					if(TF0==1){ // Did the 16-bit timer overflow?
						TF0=0;
						overflow_count++;
					}
				}
				while(P1_3!=0){ // Wait for the signal to be zero{
					if(TF0==1){ // Did the 16-bit timer overflow?
						TF0=0;
						overflow_count++;
					}
				}
			}
		 	time_diff=(overflow_count*65536.0+TH0*256.0+TL0)*(12.0/SYSCLK);
		 	time_diff=time_diff*88;
		 	ph=360/Period_1*time_diff;
		 	ph=normalizeAngle(ph);
			TR0=0;
	
			//Convert to RMS values
			v[0] = v[1]/SQRT2;
			v[2] = v[3]/SQRT2;
			
			//Print values onto LCD
			sprintf(line1, "T=%2.0fms V0=%1.2fV", Period_1, v[2]);
			LCDprint(line1, 1, 1);
			sprintf(line1, "V1=%1.2fV p=%3.0f", v[0], ph);
			LCDprint(line1, 2, 1);
			
			WriteCommand(0xCF);
			WriteData(0b11011111);   //degrees sign yay
			if( v[3]-v[4] > 0.07 )
				printf("SINE WAVE!!!\r");
			else
				printf("SQUARE WAVE!!!\r");
			
			//printf("%5.5f, %5.5f\r", time_diff, 360/Period_1*time_diff);
			waitms(50);	
			Period_1 = 0;
			time_diff = 0;
			ph=0;
			overflow_count = 0;
			for(i=0;i<4;i++)
				v[i]=0;
		}
		else if(mode == 1){
			sprintf(line1, "  PYTHON MODE   ");
			LCDprint(line1, 1, 1);
			sprintf(line1, "                ");
			LCDprint(line1, 2, 1);
			
			P0_7=1;
			v[1] = Volts_at_Pin(QFP32_MUX_P1_5);
			v[3] = Volts_at_Pin(QFP32_MUX_P1_7);
			printf("%1.2f\n", v[3]);
			printf("%1.2f\n", v[1]);
			waitms(50);
			//printf("\n\n\n");	
		}	
}
}